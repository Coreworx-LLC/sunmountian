Drop the licensed font files (woff2/woff/otf/ttf) for:
  - Freight Display Compressed Pro (Bold Italic)
  - Bicyclette (Bold, Light, Thin)
  - Avenir (Roman, Light, Book)
into your /assets/fonts/ folder, then re-zip.
